// API Routes for Ambia
const express = require('express');
const router = express.Router();

const conversationController = require('../controllers/conversationController');
const messageController = require('../controllers/messageController');
const userController = require('../controllers/userController');
const ambiaController = require('../controllers/ambiaController');

// User routes
router.post('/users/auth', userController.getOrCreateUser);
router.put('/users/:userId/preferences', userController.updatePreferences);

// Conversation routes
router.get('/users/:userId/conversations', conversationController.getUserConversations);
router.get('/conversations/:conversationId', conversationController.getConversation);
router.post('/conversations', conversationController.createConversation);
router.delete('/conversations/:conversationId', conversationController.deleteConversation);

// Message routes
router.post('/messages', messageController.createMessage);
router.post('/interactions', messageController.trackInteraction);

// Ambia AI routes - Claude API Proxy
router.post('/ambia/generate', ambiaController.generateComponents);
router.post('/ambia/feedback', ambiaController.saveFeedback);
router.get('/ambia/preferences/:userId', ambiaController.getPreferences);

// Health check
router.get('/health', (req, res) => {
  res.json({ status: 'healthy', timestamp: new Date().toISOString() });
});

module.exports = router;
